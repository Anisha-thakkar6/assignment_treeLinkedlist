#include<stdio.h> 
#include<stdlib.h> 
struct tree
{
int element;
struct tree *left;
struct tree *right;
};

struct tree *insert(struct tree *,int);
void print(struct tree *);
struct tree *delete(struct tree *,int);
int main(void)
{

struct tree *root;
int option, item,item_no;
root = NULL;
do
{
do
{
printf("\n\t 1. Enter Element in Tree");
printf("\n\t 2. Enter Element to remove");
printf("\n\t 3. Exit");
printf("\n\t Enter option : ");
scanf(" %d",&option);
if(option<1 || option>3)
printf("\n Please enter a valid option");
}while (option<1 || option>3);
switch(option)
{
case 1:
printf("\n Enter new element: ");
scanf("%d", &item);
root= insert(root,item);
printf("\n root is %d",root->element);
printf("\n Elements of binary tree is : ");
print(root);

break;
case 2:
printf("\n Enter the element to be deleted : ");
scanf(" %d",&item_no);
root=delete(root,item_no);
printf("\n root is %d",root->element);
printf("\n Elements of binary tree is : ");
print(root);

default:
printf("\n End of program ");
} /* end of switch */
}while(option !=3);
return(0);
}

struct tree *insert(struct tree *root, int x)
{
if(!root)
{
root=(struct tree*)malloc(sizeof(struct tree));
root->element = x;
root->left = NULL;
root->right = NULL;
return(root);
}
if(root->element > x)
root->left = insert(root->left,x);
else
{
if(root->element < x)
root->right = insert(root->right,x);
}
return(root);
}

void print(struct tree *root)
{
if(root != NULL)
{
print(root->left);
printf(" %d",root->element);
print(root->right);
}
return;
}

struct tree *delete(struct tree *ptr,int x)
{
struct tree *p1,*p2;
if(!ptr)
{
printf("\n Node not found ");
return(ptr);
}
else
{
if(ptr->element < x)
{
ptr->right = delete(ptr->right,x);
return(ptr);
}
else if (ptr->element >x)
{
ptr->left=delete(ptr->left,x);
return ptr;
}
else /* no. 2 else */
{
if(ptr->element == x) /* no. 2 if */
{
if(ptr->left == ptr->right) //i.e., a leaf node/
{
free(ptr);
return(NULL);
}
else if(ptr->left==NULL) /* a right subtree */
{
p1=ptr->right;
free(ptr);
return p1;
}
else if(ptr->right==NULL) /* a left subtree */
{
p1=ptr->left;
free(ptr);
return p1;
}
else
{
p1=ptr->right;
p2=ptr->right;
while(p1->left != NULL)
p1=p1->left;
p1->left=ptr->left;
free(ptr);
return p2;
}
}
}
}
return(ptr);
}